﻿namespace UiPathTeam.JSONUtilities.Activities.Design
{
    /// <summary>
    /// Interaction logic for ChildActivityDesigner.xaml
    /// </summary>
    public partial class ChildActivityDesigner
    {
        public ChildActivityDesigner()
        {
            InitializeComponent();
        }
    }
}
