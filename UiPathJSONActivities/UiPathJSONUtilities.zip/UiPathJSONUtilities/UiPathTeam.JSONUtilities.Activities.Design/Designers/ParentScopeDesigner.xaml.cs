﻿namespace UiPathTeam.JSONUtilities.Activities.Design
{
    /// <summary>
    /// Interaction logic for ParentScopeDesigner.xaml
    /// </summary>
    public partial class ParentScopeDesigner
    {
        public ParentScopeDesigner()
        {
            InitializeComponent();
        }
    }
}
