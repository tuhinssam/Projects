﻿using System.Threading.Tasks;

namespace UiPathTeam.JSONUtilities
{
    public interface IAsyncInitialization
    {
        /// <summary>
        /// The result of the asynchronous initialization of this instance.
        /// </summary>
        Task Initialization { get; }
    }
}