﻿namespace UiPathTeam.JSONUtilities.Enums
{
    public enum AuthScheme
    {
        None,
        Bearer,
        Basic
    }
}