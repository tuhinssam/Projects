﻿namespace UiPathTeam.JSONUtilities.Enums
{
    public enum TokenSource
    {
        Body,
        Cookies,
        Header
    }
}